var firstName = 
    propt ("What is your first name?");
var lastName =
    propt ("What is your last name?");

document.body.querySelector ("#box1").innerHTML=firstName;

document.body.querySelector
("box2").innerHTML=lastName;

                             
                            